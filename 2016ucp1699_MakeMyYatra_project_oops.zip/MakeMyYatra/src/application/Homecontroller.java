package application;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Homecontroller
{
	String username;
	void getusername(String s)
	{
		username=s;
		//System.out.println(username);
	}
	public void Profile(ActionEvent event) throws Exception
	{
		Stage primaryStage=new Stage();
		FXMLLoader loader=new FXMLLoader();
		Parent root = loader.load(getClass().getResource("Profile.fxml").openStream());
		
		Profilecontroller obj=(Profilecontroller)loader.getController();
		obj.getusername(username);
		obj.getroot(root);
		Scene scene = new Scene(root,400,400);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	public void AddFriends(ActionEvent event) throws Exception
	{
		Stage primaryStage=new Stage();
		FXMLLoader loader=new FXMLLoader();
		Parent root = loader.load(getClass().getResource("Addfriend.fxml").openStream());
		
		AddFriendController obj=(AddFriendController)loader.getController();
		obj.getadmin(username);
		Scene scene = new Scene(root,400,400);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	public void EditTrips(ActionEvent event) throws Exception
	{
		Stage primaryStage=new Stage();
		FXMLLoader loader=new FXMLLoader();
		Parent root = loader.load(getClass().getResource("EditTrip.fxml").openStream());
		
		EditTripController obj=(EditTripController)loader.getController();
		obj.getadmin(username);
		Scene scene = new Scene(root,400,400);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	public void Addtrips(ActionEvent event) throws Exception
	{
		Stage primaryStage=new Stage();
		FXMLLoader loader=new FXMLLoader();
		Parent root = loader.load(getClass().getResource("addtrip.fxml").openStream());
		
		addtripController obj=(addtripController)loader.getController();
		obj.getusername(username);
		Scene scene = new Scene(root,400,400);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	public void Existingtrips(ActionEvent event) throws Exception
	{
		ExistingTripController.username=username;
		Stage primaryStage=new Stage();
		FXMLLoader loader=new FXMLLoader();
		Parent root = loader.load(getClass().getResource("Existingtrips.fxml").openStream());
		
		Scene scene = new Scene(root,400,400);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	public void exit(ActionEvent event) throws Exception
	{
		System.exit(0);
	}
}