package application;

import java.sql.Connection;
import java.sql.SQLException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class Editprofilecontroller
{
	String username;
	public void getadmin(String a)
	{
		username=a;
	}
	@FXML
	protected TextField name;
	
	@FXML
	protected TextField email;
	
	@FXML
	protected TextField password;
	
	@FXML
	protected Label status;
	
	public void Edit(ActionEvent event) throws Exception
	{
		
		
		Connector myconnector=new Connector();
		Connection con=myconnector.getConn();
		java.sql.Statement stmt=null;
		
		try
		{
			stmt=con.createStatement();
		}
		catch(SQLException e)
		{
			System.out.println("Error in Creating Statement in Add user");
		}
		try
		{
			//System.out.println(Integer.parseInt(tid.getText()));
			
			if(!name.getText().isEmpty())
			{
				String Q1="UPDATE users SET name='"+name.getText()+"' WHERE username ='"+username+"';";
				stmt.executeUpdate(Q1);
				status.setText("Name Updated");
			}
			if(!email.getText().isEmpty())
			{
				String Q1="UPDATE users SET email='"+email.getText()+"' WHERE username ='"+username+"';";
				stmt.executeUpdate(Q1);
				status.setText("Email Updated");
			}
			if(!password.getText().isEmpty())
			{
				String Q1="UPDATE users SET password='"+password.getText()+"' WHERE username ='"+username+"';";
				stmt.executeUpdate(Q1);
				status.setText("Password Updated");
			}
			
		}
		catch(SQLException e)
		{
			System.out.println("Error in Query Edit trip");
		}
		myconnector.Closeconn(stmt, con);
	}
	
	
}
