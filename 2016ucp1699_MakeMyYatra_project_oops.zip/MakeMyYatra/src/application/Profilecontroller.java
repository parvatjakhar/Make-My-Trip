package application;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.stage.Stage;

public class Profilecontroller
{
	
	String username;
	Parent root;
	public void getusername(String a)
	{
		username=a;
	}
	public void getroot(Parent a)
	{
		root=a;
	}
	@FXML
	protected Label name;
	
	@FXML
	protected Label email;
	@FXML
	protected Label userid;
	@FXML
	protected PasswordField password;
	
	public void show(ActionEvent event) throws Exception
	{
		Connector myconnector=new Connector();
		Connection con=myconnector.getConn();
		java.sql.Statement stmt=null;
		try
		{
			stmt=con.createStatement();
		}
		catch(SQLException e)
		{
			System.out.println("Error in Creating Statement in Existing Trip Controller");
		}
		try 
		{
			String Q1="SELECT * FROM users WHERE username='"+username+"';";
			ResultSet rs1= stmt.executeQuery(Q1);
			if(rs1.next())
			{
				name.setText(rs1.getString(2));
				email.setText(rs1.getString(4));
				userid.setText(username);
			}
		}
		catch (SQLException e)
		{
			System.out.println("Error In Connection Establishment profilecontrollr.jav");
		}
		myconnector.Closeconn(stmt, con);
	}
	public void Edit(ActionEvent event) throws Exception
	{
		Stage primaryStage=new Stage();
		FXMLLoader loader=new FXMLLoader();
		root = loader.load(getClass().getResource("Editprofile.fxml").openStream());
		
		Editprofilecontroller obj=(Editprofilecontroller)loader.getController();
		obj.getadmin(username);
		Scene scene = new Scene(root,400,400);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
}
