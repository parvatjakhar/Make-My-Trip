package application;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class EditTripController
{
	String admin;
	public void getadmin(String a)
	{
		admin=a;
	}
	@FXML
	protected TextField tid;
	
	@FXML
	protected DatePicker sdate;

	@FXML
	protected DatePicker edate;
	
	@FXML
	protected TextField destination;
	
	@FXML
	protected TextField bookings;
	
	@FXML
	protected TextField expenses;
	
	
	@FXML
	protected Label status;
	
	LocalDate sdate1,edate1;
	
	
	public void Edit(ActionEvent event) throws Exception
	{
		sdate1=sdate.getValue();
		edate1=edate.getValue();
		

		
		if(tid.getText().isEmpty())
		{
			status.setText("Please Fill the Fields");
		}
		else
		{
			Connector myconnector=new Connector();
			Connection con=myconnector.getConn();
			java.sql.Statement stmt=null;
			
			try
			{
				stmt=con.createStatement();
			}
			catch(SQLException e)
			{
				System.out.println("Error in Creating Statement in Add user");
			}
			try
			{
				//System.out.println(Integer.parseInt(tid.getText()));
				
				String Q1="SELECT * FROM trips WHERE tid ="+Integer.parseInt(tid.getText())+" AND admin='"+admin+"';";
				ResultSet rs1= stmt.executeQuery(Q1);
				
				if(rs1.next()==false)
				{
					status.setText("You Are Not An Admin Of this Trip...");
				}
				else
				{
					if(!destination.getText().isEmpty())
					{
						Q1="UPDATE trips SET destination='"+destination.getText()+"' WHERE tid ="+Integer.parseInt(tid.getText())+";";
						stmt.executeUpdate(Q1);
						status.setText("Destion Updated");
					}
					if(!bookings.getText().isEmpty())
					{
						Q1="UPDATE trips SET bookings='"+bookings.getText()+"' WHERE tid ="+Integer.parseInt(tid.getText())+";";
						stmt.executeUpdate(Q1);
						status.setText("Bookings Updated");
					}
					if(!expenses.getText().isEmpty())
					{
						Q1="UPDATE trips SET expenses="+Integer.parseInt(expenses.getText())+" WHERE tid ="+Integer.parseInt(tid.getText())+";";
						stmt.executeUpdate(Q1);
						status.setText("expenses Updated");
					}
					if(sdate1!=null)
					{
						Q1="UPDATE trips SET sdate='"+sdate1+"' WHERE tid ="+Integer.parseInt(tid.getText())+";";
						stmt.executeUpdate(Q1);
						status.setText("Start Date Updated");
					}
					if(edate1!=null)
					{
						Q1="UPDATE trips SET edate='"+edate1+"' WHERE tid ="+Integer.parseInt(tid.getText())+";";
						stmt.executeUpdate(Q1);
						status.setText("End date Updated");
					}
				}
			}
			catch(SQLException e)
			{
				System.out.println("Error in Query Edit trip");
			}
			myconnector.Closeconn(stmt, con);
		}
	}
	
}
