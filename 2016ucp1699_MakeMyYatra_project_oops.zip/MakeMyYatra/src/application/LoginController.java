package application;


import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class LoginController
{
	@FXML
	private Label status;
	
	@FXML
	private PasswordField password;
	
	@FXML
	private TextField username;

	public void Login(ActionEvent event) throws Exception
	{
		//System.out.println(password.getText());
		//System.out.println(username.getText());
		
		if(password.getText().isEmpty()||username.getText().isEmpty())
		{
			status.setText("Please Fill the Field");
		}
		else
		{
			Connector myconnector=new Connector();
			Connection con=myconnector.getConn();
			ResultSet rs=null;
			try
			{
				java.sql.Statement stmt=con.createStatement();
				String Q="SELECT * FROM users WHERE username ='"+username.getText()+"'and password='"+password.getText()+"';";					
				rs = stmt.executeQuery(Q);
				if(rs.next())
				{
					status.setText("Success");
					Stage primaryStage=new Stage();
					FXMLLoader loader=new FXMLLoader();
					Parent root = loader.load(getClass().getResource("Home.fxml").openStream());
					
					Homecontroller homecontroller=(Homecontroller)loader.getController();
					homecontroller.getusername(username.getText());
					Scene scene = new Scene(root,400,400);
					scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
					primaryStage.setScene(scene);
					primaryStage.show();
				}
				else
				{
					status.setText("Invalid Credentials");
				}
				try
				{
					if(stmt !=null)
					{
						stmt.close();
						stmt=null;
					}
				}
				catch(SQLException e)
				{
					System.out.println("Error in Closing Connection");
				}
			}
			catch(IOException e)
			{
				System.out.println("Exception in IO username");
			}
			catch(SQLException e)
			{
				System.out.println("Error in Statement");
			}
			try
			{
				if(con !=null)
				{
					con.close();
					con=null;
				}
			}
			catch(SQLException e)
			{
				System.out.println("Error in Closing Connection");
			}
		}
	}
	public void forgot(ActionEvent event) throws Exception
	{
		Stage primaryStage=new Stage();
		FXMLLoader loader=new FXMLLoader();
		Parent root = loader.load(getClass().getResource("Forgot.fxml").openStream());
		
		Forgotcontroller obj=(Forgotcontroller)loader.getController();
		System.out.println(username.getText());
		obj.getadmin(username.getText());
		Scene scene = new Scene(root,400,400);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	}
}
