package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Connector
{
	Connection getConn()
	{
		Connection con = null;
		try
		{
			String driver="com.mysql.cj.jdbc.Driver";
			Class.forName(driver);
		}
		catch(ClassNotFoundException e)
		{
			System.out.println("Exception IN connection Establishing Connector.java1");
		}
		String url="jdbc:mysql://localhost:3306/myDB";
		String pass="";
		String username="root";
		try
		{
			con=DriverManager.getConnection(url,username,pass);
			//return con;
		}
		catch(SQLException e)
		{
			System.out.println("Exception IN connection Establishing Connector.java2");
		}
		return con;
		
	}
	void Closeconn(java.sql.Statement stmt,Connection con)
	{
		try
		{
			if(stmt !=null)
			{
				stmt.close();
				stmt=null;
			}
			if(con !=null)
			{
				con.close();
				con=null;
			}
		}
		catch(SQLException e)
		{
			System.out.println("Error in Closing Statement");
		}
	}
}
