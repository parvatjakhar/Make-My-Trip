package application;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class Aboutuscontroller
{
	@FXML
	protected Label id1;
	@FXML
	protected Label id2;
}
