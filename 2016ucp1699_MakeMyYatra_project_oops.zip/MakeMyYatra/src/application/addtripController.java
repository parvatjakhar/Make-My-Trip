package application;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import javafx.fxml.FXML;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class addtripController
{
	@FXML
	protected DatePicker sdate;

	@FXML
	protected DatePicker edate;
	
	@FXML
	protected TextField destination;
	
	@FXML
	protected TextField bookings;
	
	@FXML
	protected TextField tid;
	
	@FXML
	protected Label status;
	
	String username;
	
	
	LocalDate sdate1,edate1;
	
	public void addtrip()
	{
		
		sdate1=sdate.getValue();
		edate1=edate.getValue();
		
		Connector myconnector=new Connector();
		Connection con=myconnector.getConn();
		java.sql.Statement stmt=null,stmt2=null,stmt3=null;
		try
		{
			stmt=con.createStatement();
			stmt2=con.createStatement();
			stmt3=con.createStatement();
		}
		catch(SQLException e)
		{
			System.out.println("Error in Creating Statement");
		}
		try
		{
			
			String Q2="SELECT * FROM trips WHERE tid ="+tid.getText()+";";
			ResultSet rs2= stmt3.executeQuery(Q2);
			if(rs2.next())
			{
				status.setText("Trip id Already Exists...\n Change to Unique One");
			}
			else
			{
				String Q="INSERT INTO trips() VALUES ("+tid.getText()+",'"+username+"','"+sdate1+"','"+edate1+"','"+destination.getText()+"','"+bookings.getText()+"',"+0+");";
				
				status.setText("Trip Added Successfully...");
				
				stmt.executeUpdate(Q);
				
				System.out.println(1);
				
				Q2="INSERT INTO trip_user() VALUES ("+tid.getText()+",'"+username+"',"+0+");";
				
				stmt2.executeUpdate(Q2);
			
			System.out.println(2);
			}
		}
		catch(SQLException e)
		{
			System.out.println("Eror In Adding Trip");
		}
		myconnector.Closeconn(stmt, con);
		myconnector.Closeconn(stmt2, con);
		myconnector.Closeconn(stmt3, con);
	}
	public void getusername(String u)
	{
		username=u;
	}
}