package application;

import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;

public class ExistingTripController implements Initializable
{
	static String username;
	void getusername(String u)
	{
		username=u;
	}
	
	@FXML
	private TableView<Trip> table;
	@FXML
	private TableColumn<Trip,Integer> tid;
	@FXML
	private TableColumn<Trip,Integer> expenses;
	@FXML
	private TableColumn<Trip,String> admin;
	@FXML
	private TableColumn<Trip,LocalDate>sdate;
	@FXML
	private TableColumn<Trip,LocalDate>edate;
	@FXML
	private TableColumn<Trip,String> destination;
	@FXML
	private TableColumn<Trip,String> booking;
	
	public ObservableList<Trip> list = FXCollections.observableArrayList();
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1)
	{
		//System.out.println("3"+username);
		
		Connector myconnector=new Connector();
		Connection con=myconnector.getConn();
		java.sql.Statement stmt=null,stmt1=null;
		try
		{
			stmt=con.createStatement();
			stmt1=con.createStatement();
		}
		catch(SQLException e)
		{
			System.out.println("Error in Creating Statement in Existing Trip Controller");
		}
		try 
		{
			String Q1="SELECT * FROM trip_user WHERE username='"+username+"';";
			ResultSet rs1= stmt1.executeQuery(Q1);
			
			while(rs1.next())
			{
				//System.out.println(rs1.getInt(1));
				String Q="SELECT * FROM trips WHERE tid="+rs1.getInt(1)+";";
				ResultSet rs= stmt.executeQuery(Q);
				while(rs.next())
				{
					list.add(new Trip((rs.getInt(1)),rs.getDate(3),
							rs.getDate(4),rs.getString(2),rs.getString(5),rs.getString(6),rs.getInt(7)));
					
				}
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		myconnector.Closeconn(stmt, con);
		myconnector.Closeconn(stmt1, con);
		
		tid.setCellValueFactory(new PropertyValueFactory<Trip, Integer>("tid"));
		admin.setCellValueFactory(new PropertyValueFactory<Trip, String>("admin"));
		sdate.setCellValueFactory(new PropertyValueFactory<Trip, LocalDate>("sdate"));
		edate.setCellValueFactory(new PropertyValueFactory<Trip, LocalDate>("edate"));
		destination.setCellValueFactory(new PropertyValueFactory<Trip, String>("destination"));
		booking.setCellValueFactory(new PropertyValueFactory<Trip, String>("booking"));
		expenses.setCellValueFactory(new PropertyValueFactory<Trip, Integer>("expenses"));
		table.setItems(list);
	}
}
