package application;

import java.util.Date;

public class Trip 
{
	public int tid;
	public Date sdate;
	public Date edate;
	public String admin;
	public String destination;
	public String booking;
	public int expenses;
	public Trip(int tid,Date sdate, Date edate, String admin, String destination, String booking,int e)
	{
		super();
		this.tid = tid;
		this.sdate = sdate;
		this.edate = edate;
		this.admin = admin;
		this.destination = destination;
		this.booking = booking;
		this.expenses=e;
	}
	public int getTid() {
		return tid;
	}
	public void setTid(int tid) {
		this.tid = tid;
	}
	public int getExpenses() {
		return expenses;
	}
	public void setExpenses(int ex) {
		this.expenses = ex;
	}
	public Date getSdate() {
		return sdate;
	}
	public void setSdate(Date sdate) {
		this.sdate = sdate;
	}
	public Date getEdate() {
		return edate;
	}
	public void setEdate(Date edate) {
		this.edate = edate;
	}
	public String getAdmin() {
		return admin;
	}
	public void setAdmin(String admin) {
		this.admin = admin;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getBooking() {
		return booking;
	}
	public void setBooking(String booking) {
		this.booking = booking;
	}
	
}
