package application;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class AddFriendController
{
	String admin;
	public void getadmin(String a)
	{
		admin=a;
	}
	@FXML
	protected TextField tid;
	
	@FXML
	protected TextField user;
	
	@FXML
	protected Label status;
	
	public void Add(ActionEvent event) throws Exception
	{
		if(tid.getText().isEmpty()||user.getText().isEmpty())
		{
			status.setText("Please Fill the Fields");
		}
		else
		{
			Connector myconnector=new Connector();
			Connection con=myconnector.getConn();
			java.sql.Statement stmt=null,stmt2=null,stmt1=null;
			 
			try
			{
				stmt=con.createStatement();
				stmt2=con.createStatement();
				stmt1=con.createStatement();
			}
			catch(SQLException e)
			{
				System.out.println("Error in Creating Statement in Add user");
			}
			try
			{
				//System.out.println(Integer.parseInt(tid.getText()));
				
				String Q1="SELECT * FROM trips WHERE tid ="+Integer.parseInt(tid.getText())+" AND admin='"+admin+"';";
				ResultSet rs1= stmt.executeQuery(Q1);
				
				if(rs1.next()==false)
				{
					status.setText("You Are Not An Admin Of this Trip...");
				}
				else
				{
					//System.out.println("2");
					
					Q1="SELECT * FROM trip_user WHERE tid ="+Integer.parseInt(tid.getText())+" AND username='"+user+"';";
					ResultSet rs2= stmt1.executeQuery(Q1);
					
					if(rs2.next())
					{
						status.setText("User Already Exists in the Trip...");
					}
					else
					{
						try
						{
							 Q1="INSERT INTO trip_user VALUES ("+Integer.parseInt(tid.getText())+",'"+user.getText()+"',"+0+");";
							
							 status.setText("User Added Successfully...");
							 
							 stmt2.executeUpdate(Q1);
						}
						catch(SQLException e)
						{
							System.out.println("Error in Query add friend1");
						}
					}
				}
			}
			catch(SQLException e)
			{
				System.out.println("Error in Query add friend2");
			}
			
			myconnector.Closeconn(stmt, con);
		}
	}
}
