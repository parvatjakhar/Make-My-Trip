package application;



import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class RegisterController
{
	@FXML
	private TextField username;
	
	@FXML
	private TextField name;
	
	@FXML
	private TextField email;
	
	@FXML
	private PasswordField password;
	@FXML
	private PasswordField cpassword;

	@FXML
	private Label status;
	
	public void Register(ActionEvent event) throws Exception
	{
		if(password.getText().isEmpty()||username.getText().isEmpty()||email.getText().isEmpty())
		{
			status.setText("Please Fill the Field");
		}
		else if(!password.getText().equals(cpassword.getText()))
		{
			status.setText("Password Did not Match");
			//System.out.println(password);
			//System.out.println(cpassword);
		}
		else
		{
			Connector myconnector=new Connector();
			Connection con=myconnector.getConn();
			java.sql.Statement stmt=null;
			try
			{
				stmt=con.createStatement();
			}
			catch(SQLException e)
			{
				System.out.println("Error in Creating Statement");
			}
			
			String Q2="SELECT * FROM users WHERE email ='"+email.getText()+"';";
			ResultSet rs2= stmt.executeQuery(Q2);
			if(rs2.next())
			{
				status.setText("Email Already Exists...");
			}
			else
			{
				int f=0;
				try
				{
					String Q3="INSERT INTO users VALUES ('"+username.getText()+"','"+name.getText()+"','"+password.getText()+"','"+email.getText()+"');";
					
					stmt.executeUpdate(Q3);
				}
				catch(SQLException e)
				{
					f=1;
				}
				if(f==1)
					status.setText("Username Already Exists...");
				else
					status.setText("Registration Successful.. \n Now Login With your details!");
			}
			myconnector.Closeconn(stmt, con);
		}
	}
}
